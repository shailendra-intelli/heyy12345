import React, { useEffect, useState } from "react";
import {
  Button,
  Card,
  InputWithMovingLabel,
  DropDown,
  Modal
} from "intelli-ui-components-library";
import { useAppDispatch, useAppSelector } from "../../../../store/hooks";
import { updatePath, DEFAULT_Response_OBJ } from "../../mainTabsSlice";
import {
  DeleteIcon,
  CopyIcon,
  AddIcon,
  EditIcon,
  HeaderIcon,
} from "../../../../assets/icons";
import NoMediaTypes from "./NoMediaTypes";
import {
  ResponseDetails,
  deleteMethod,
} from "../../../../store/reducers/mainTabsSlice";
import { Value } from "sass";
import styles from "./path_sub_tab_responses.module.scss"
import ace from "brace";
import { JsonEditor as Editor } from "jsoneditor-react";
import "jsoneditor-react/es/editor.min.css";
import "brace/mode/json";
import "brace/theme/github";


const PathSubTabResponses = ({ pathName, methodName }: any) => {
  const paths = useAppSelector((state) => state.main.paths);
  const [showModal, setShowModal] = useState(false);
  const methodData = paths[pathName]?.[methodName]; // Null check added here
  const responses = methodData?.responses || {}; // Null check added here
  const dispatch = useAppDispatch();
  const schemaData = useAppSelector(state=>state.schema.schemas);
  const [json, setJson] = useState();
  const [responsesArr, setResponsesArr] = useState<any>([
    ...Object.entries(responses),
  ]);
  const [editedMediaType, setEditedMediaType] = useState("");
  const [reSchema, setReSchema] = useState(false);
  const [selectValue, setSelectValue] = useState();
  let optionList = [];
  optionList= Object.keys(schemaData).map((schemaKey,index)=>{
      return {label:schemaKey, key:schemaKey}
     })
 // console.log("optionList",optionList)
  useEffect(() => {
   // console.log("responsesArr",responsesArr);
    const newResponsesState = [...responsesArr].reduce((acc, curr) => {
      acc[curr[0]] = curr[1];
      return acc;
    }, {});
    dispatch(
      updatePath({
        pathName,
        methodName,
        methodKey: "responses",
        data: {
          ...newResponsesState,
        },
      })
    );
  }, [responsesArr]);
  const reuseSchema = () => {
     setReSchema(true);
  }

  return (
    <div className="mt-6">
      <div>
        {[...responsesArr].map((arr: any, index) => {
          const statusCode = arr[0];
          const responseDetails: ResponseDetails = arr[1];
          const mediaTypes = responseDetails.content ?? {};
          const newresponseContent = {...responseDetails.content}
          return (
            <div key={statusCode}>
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-evenly",
                  paddingTop: "18px",
                }}
              >
                <div className="text-left w-full">
                  <button
                    className="bg-gray-400 rounded-md p-1 disabled:bg-gray-200 hover:bg-gray-500"
                    title="Add Response"
                    onClick={() => {
                      const lastResponse =
                        responsesArr[responsesArr.length - 1];
                      const lastResponseStatusCode = Number(lastResponse[0]);
                      const updatedResponsesArr = [
                        ...responsesArr,
                        [`${lastResponseStatusCode + 1}`,{}],
                      ];
                      setResponsesArr([...updatedResponsesArr]);
                    }}
                  >
                    <AddIcon fill="#000" width="20px" height="20px" />
                  </button>
                  <button title="Duplicate Response" onClick={() => {}}>
                    <CopyIcon fill="#FFFFFF" width="20px" height="20px" />
                  </button>

                  <button
                    className="bg-gray-400 rounded-md p-1 disabled:bg-gray-200 hover:bg-gray-500"
                    title="Delete Response"
                    onClick={() => {
                      const updatedResponsesArr = responsesArr.filter(
                        (arr, i) => i !== index
                      );

                      setResponsesArr([...updatedResponsesArr]);
                    }}
                  >
                    <DeleteIcon fill="#FFFFFF" width="20px" height="20px" />
                  </button>
                </div>
                <ResponseStatusCode
                  statusCode={statusCode}
                  handleStatusCodeChange={(newVal: any) => {
                    const newStatusCode = newVal;
                    const newArr = [newStatusCode, responseDetails];
                    const updatedResponsesArr = [
                      ...responsesArr.slice(0, index),
                      newArr,
                      ...responsesArr.slice(index + 1),
                    ];
                    setResponsesArr([...updatedResponsesArr]);
                  }}
                />
                <ResponseDescription
                  description={responseDetails.description ?? ""}
                  handleDescriptionChange={(newVal: any) => {
                    const newResponseDetails = {
                      ...responseDetails,
                      description: newVal,
                    };
                    const newArr = [statusCode, newResponseDetails];
                    const updatedResponsesArr = [
                      ...responsesArr.slice(0, index),
                      newArr,
                      ...responsesArr.slice(index + 1),
                    ];
                    setResponsesArr([...updatedResponsesArr]);
                  }}
                />
              </div>

              {Object.keys(mediaTypes).length === 0 ? (
                <NoMediaTypes
                  pathName={pathName}
                  methodName={methodName}
                  onClick={() => {
                    const newResponseDetails = {
                      ...responseDetails,
                      content: {
                        ["change/me"]: {
                          schema: {},
                        },
                      },
                    };
                    const newArr = [statusCode, newResponseDetails];
                    const updatedResponsesArr = [
                      ...responsesArr.slice(0, index),
                      newArr,
                      ...responsesArr.slice(index + 1),
                    ];
                    setResponsesArr([...updatedResponsesArr]);
                  }}
                />
              ) : (
                <div>
                  {Object.keys(mediaTypes).map(
                    (mediaTypeKey, mediaTypeKeyIndex) => (
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "center",
                          paddingTop: "12px",
                        }}
                      >
                        <div style={{ width: "50%", display: "flex", height: "38px" }}>
                          <button
                            title="Add Media Type"
                            onClick={() => {
                              // Extracting existing content from responseDetails
                              const { content, ...restDetails } =
                                responseDetails;

                              // Creating a new response with the duplicated "MediaType" input box
                              const newResponseDetails = {
                                ...restDetails,
                                content: {
                                  ...content,
                                  ["change/me"]: {
                                    schema: {},
                                  },
                                },
                              };

                              // Use the length of responsesArr as a key (not recommended for all scenarios)
                              const newResponseKey = responsesArr.length;

                              // Update the responses array by adding the new response
                              const updatedResponsesArr = [
                                ...responsesArr,
                                [newResponseKey, newResponseDetails],
                              ];

                              setResponsesArr(updatedResponsesArr);
                            }}
                          >
                            <AddIcon fill="#000" width="15px" height="15px" />
                          </button>
                          <button title="Copy Media Type" onClick={() => {}}>
                            <CopyIcon
                              fill="#FFFFFF"
                              width="20px"
                              height="15px"
                            />
                          </button>
                          <button title="Edit Media Type" onClick={() => setShowModal(true)}>
                            <EditIcon fill="#000" width="20px" height="18px" />
                          </button>
                          {showModal && (
                            <Modal
                              onHidden={() => {
                                setShowModal(false);
                              }}
                              showOverlay={true}
                              setting={{
                                modalId: "center-btn",
                                className: styles.schemaModel,
                                variant: "action",
                              }}
                              childClassName={styles.schemaContents}
                            >
                              <div><Modal.CloseIcon onClick={()=>{
                                setShowModal(false);
                                const newResponseDetails = {
                                  ...responseDetails,
                                  content: {
                                    ...responseDetails.content, 
                                    [mediaTypeKey]: {
                                      schema: json
                                    },
                                   
                                  },
                                };
                                const newArr = [statusCode, newResponseDetails];
                                const updatedResponsesArr = [
                                  ...responsesArr.slice(0, index),
                                  newArr,
                                  ...responsesArr.slice(index + 1),
                                ];
                                setResponsesArr([...updatedResponsesArr]);
                              
                              }} /></div>
                              <Modal.Body className={styles["model-body"]}>
                                <div className="pdlr-20 pdtb-10">
                                  <Editor
                                    mode="tree"
                                    history
                                    value={newresponseContent[mediaTypeKey]["schema"]}
                                    onChange={setJson}
                                    ace={ace}
                                    theme="ace/theme/github"
                                  />
                                </div>
                              </Modal.Body>
                            </Modal>
                          )}
                          { !reSchema && (
                            <button title="Re-use shared schema" onClick={reuseSchema}>
                              <HeaderIcon fill="#000" width="20px" height="18px" />
                            </button>
                          )}
                           { reSchema && (
                            <DropDown 
                              optionList={optionList}
                              className={styles["use-schema"]}
                              value = {selectValue}
                              onChange={(e)=>{
                                setSelectValue(e.key);
                                const newResponseDetails = {
                                  ...responseDetails,
                                  content: {
                                    ...responseDetails.content, 
                                    [mediaTypeKey]: {
                                      schema: schemaData[e.key]
                                    },
                                   
                                  },
                                };
                                console.log("newResponseDetails",newResponseDetails);
                                const newArr = [statusCode, newResponseDetails];
                                const updatedResponsesArr = [
                                  ...responsesArr.slice(0, index),
                                  newArr,
                                  ...responsesArr.slice(index + 1),
                                ];
                                setResponsesArr([...updatedResponsesArr]);
                              
                        
                              }}
                              />
                              
                          )}
                          <button
                            title="Delete Response"
                            onClick={() => {
                              const updatedResponses = {
                                ...paths[pathName]?.[methodName]?.responses,
                              };

                              if (mediaTypeKey in updatedResponses) {
                                const {
                                  [mediaTypeKey]: deletedResponse,
                                  ...remainingResponses
                                } = updatedResponses;

                                console.log(
                                  "Deleting response with mediaTypeKey:",
                                  mediaTypeKey
                                );
                                console.log(
                                  "Updated responses:",
                                  remainingResponses
                                );

                                dispatch(
                                  updatePath({
                                    pathName,
                                    methodName,
                                    methodKey: "responses",
                                    data: remainingResponses,
                                  })
                                );
                              } else {
                                console.warn(
                                  `Response with mediaTypeKey ${mediaTypeKey} not found.`
                                );
                              }
                            }}
                          >
                            <DeleteIcon
                              fill="#000"
                              width="15px"
                              height="15px"
                            />
                          </button>
                        </div>
                        <div style={{ width: "78%" }}>
                          <InputMediaType
                            mediaTypeKey={mediaTypeKey}
                            handleMediaTypeKeyChange={(val: any) => {
                              const newMediaTypeKey = val;
                            //   const newResponseDetails = {...responseDetails}
                            //   const newResContents = {...newResponseDetails.content}
                            //   const oldVlaue = { ...newResContents[mediaTypeKey] };
                            //   const keyValues = Object.entries(newResContents);
                            //   keyValues.splice(index, 1, [newMediaTypeKey, oldVlaue]);
                            //   const newObj = Object.fromEntries(keyValues);
                            //   newResponseDetails.content = {...newObj};

                              const newResponseDetails = {
                                ...responseDetails,
                                content: {
                                  
                                  [newMediaTypeKey]: {
                                    ...responseDetails.content[mediaTypeKey],
                                  },
                                  ...responseDetails.content, 
                                },
                              };
                              delete newResponseDetails.content[mediaTypeKey];
                              const newArr = [statusCode, newResponseDetails];
                              const updatedResponsesArr = [
                                ...responsesArr.slice(0, index),
                                newArr,
                                ...responsesArr.slice(index + 1),
                              ];
                              setResponsesArr([...updatedResponsesArr]);
                            }}
                          />
                        </div>
                      </div>
                    )
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default PathSubTabResponses;

const ResponseStatusCode = ({
  statusCode,
  handleStatusCodeChange,
}: {
  statusCode: any;
  handleStatusCodeChange: any;
}) => {
  const [currVal, setCurrVal] = useState(statusCode ?? "");
  return (
    <InputWithMovingLabel
      inputProps={{
        label: "Status Code",
        name: "response.statusCode",
        value: currVal,
        onChange: (e) => setCurrVal(e.target.value),
        onBlur: () => handleStatusCodeChange(currVal),
        type: "text",
      }}
      top
      className="mb-4"
    />
  );
};

const ResponseDescription = ({
  description,
  handleDescriptionChange,
}: {
  description: any;
  handleDescriptionChange: any;
}) => {
  return (
    <InputWithMovingLabel
      inputProps={{
        label: "Description",
        name: "response.description",
        value: description ?? "",
        onChange: (e) => handleDescriptionChange(e.target.value),
        type: "text",
      }}
      top
      className="mb-4"
    />
  );
};

const InputMediaType = ({
  mediaTypeKey,
  handleMediaTypeKeyChange,
}: {
  mediaTypeKey: any;
  handleMediaTypeKeyChange: any;
}) => {
  const [currVal, setCurrVal] = useState(mediaTypeKey ?? "");
  return (
    <InputWithMovingLabel
      key={mediaTypeKey}
      inputProps={{
        label: "Media Type",
        name: `response.mediaType.${mediaTypeKey}`,
        value: currVal,
        onChange: (e) => setCurrVal(e.target.value),
        onBlur: () => handleMediaTypeKeyChange(currVal),
        type: "text",
      }}
      top
      className="mb-4"
    />
  );
};

const ResponseMediaTypes = ({
  mediaTypes,
  pathName,
  methodName,
}: {
  mediaTypes: any;
  pathName: any;
  methodName: any;
}) => {
  return <></>;
};
