import React from "react";

const PathSubTabCallbacks = () => {
  return <div>PathSubTabCallbacks</div>;
};

export default PathSubTabCallbacks;
