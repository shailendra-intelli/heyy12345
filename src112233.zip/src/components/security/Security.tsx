import { Button } from "intelli-ui-components-library";
import { LeftArrowIcon, RightArrowIcon } from "../../assets/icons";
import styles from "./security.module.scss";
import { useNavigate } from "react-router-dom";

const Security = () =>{
    const navigate = useNavigate();
    return (
        <div>
        <div style={{marginTop:"100px", color:"#747474"}}>
            <h1><center>Work-In-Progress</center></h1>
        </div>
        <div className={styles["container"]}>
          <Button className={styles["button"]} onClick={()=>navigate("/api-doc-gen/tags")}>
            {" "}
            Next
            <span>
              <RightArrowIcon fill="#FFFFFF" width={"18px"} height={"16px"} />
            </span>
          </Button>
          <Button className={styles["button"]} onClick={()=>navigate("/api-doc-gen/api-servers")}>
            {" "}
            <span style={{marginRight:"3px"}}>
              <LeftArrowIcon fill="#FFFFFF" width={"18px"} height={"16px"} />
            </span>
            Back
          </Button>
        </div>
        </div>
    )
}
export default Security;