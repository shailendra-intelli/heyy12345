import {
  HomeIcon,
  UploadIcon,
  HeaderIcon,
  ServersIcon,
  ExportsIcon,
  TagsIcon,
  EditIconOutlined,
  SchemasIcon,
  PathAndOperationsIcon,
  LoadSpecIcon,
  TestBuilderIcon,
  TestExecutorIcon,
  SecurityIcon,
} from "../../assets/icons";

export interface SidebarItem {
  path: string;
  title: string;
  icon: any;
  id: string;
}

export const sidebarMenu = [
  {
    path: "/Home",
    title: "Home",
    icon: HomeIcon,
    id: "home",
  },
  {
    path: "/api-doc-gen/upload",
    title: "API Spec",
    desc: "Create New API Specification OR Update Existing API Specification",
    icon: LoadSpecIcon,
    id: "upload",
  },
  {
    path: "/api-doc-gen/spec-info",
    title: "Document Info",
    desc: "Specify documentation info such as Name, Version, Contact Details, URL and Other Details.",
    icon: HeaderIcon,
    id: "header",
  },
  {
    path: "/api-doc-gen/api-servers",
    title: "API Servers",
    desc: "Specify Host URL and BasePath for API endpoints.",
    icon: ServersIcon,
    id: "servers",
  },
  {
    path: "/api-doc-gen/security",
    title: "Security",
    desc: "Specify Security Schemes for APIs.",
    icon: SecurityIcon,
    id: "security",
  },
  {
    path: "/api-doc-gen/tags",
    title: "Tags",
    desc: "Specify Grouping mechanism for categorizing API operations.",
    icon: TagsIcon,
    id: "tags",
  },
  {
    path: "/api-doc-gen/schemas",
    title: "Schemas",
    desc: "Specify Structure and data types of request/response payloads.",
    icon: SchemasIcon,
    id: "schemas",
  },
  {
    path: "/api-doc-gen/path-and-operations",
    title: "Path & Operations",
    desc: "Specify API endpoints and supported HTTP methods with related information.",
    icon: PathAndOperationsIcon,
    id: "main",
  },
  {
    path: "/api-doc-gen/exports",
    title: "Exports",
    desc: "Get the documentation based on the information provided to API DocGen.	",
    icon: ExportsIcon,
    id: "exports",
  },
  {
    path: "/test-wizard/test-builder",
    title: "Test Case Generator",
    desc: "Generate API requests in the form of Test collection.",
    icon: TestBuilderIcon,
    id: "apiValidator",
  },
  {
    path: "/test-wizard/test-executor",
    title: "Test Executor",
    desc: "Execute the API Test collection",
    icon: TestExecutorIcon,
    id: "apiValidator",
  },
];
